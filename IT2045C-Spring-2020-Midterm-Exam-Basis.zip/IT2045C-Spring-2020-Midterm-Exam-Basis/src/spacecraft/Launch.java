/*
 * Name: Noah Broyles
 * Email: broylend@mail.uc.edu
 * Midterm Exam
 * Due Date: 3/05/2020
 * Course: Computer Programming 2, Spring 2020 
 */

package spacecraft;

/***
 * The Launch behavior of something that can launch.
 * @author nicomp
 *
 */
public interface Launch {
	void Launch(); // I wish this had been lowercase
}
